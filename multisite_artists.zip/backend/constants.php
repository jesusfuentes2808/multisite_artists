<?php
const URL_MAIN = 'http://artistas.test:8084/';
const URL = 'http://artistas.test:8084/wp-json/v1';
const URL_JSON = 'http://artistas.test:8084/wp-content/json';
const ALIAS = 'ricardomontaner_123';

//CLAVE SECRETA
//6Ldj7LwdAAAAAInaEXJjC8m1YrIz0rwAgFfs8q21
//CLAVE SECRETA OVERFLOW
//6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe
//CLAVE SITIO
//6Ldj7LwdAAAAAPy7Ya8PkHRnD7ikt0f9PevpxUG_

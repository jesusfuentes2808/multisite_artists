<?php
require('./backend/helper.php');
require('./backend/request.php');
require('./backend/youtube.php');
require('./backend/spotify.php');

$url = URL;
$alias = ALIAS;
$urlJson = URL_JSON;

// ARTIST MAIN CONTENT
$filename = dirname(__FILE__) . '/assets/json/artist.json';

if (file_exists($filename)) {
    $contentArtist = file_get_contents($filename);
    $data = json_decode($contentArtist);
} else {
    $contentArtist = requestUrl($urlJson . "/$alias/artist.json");
    $data = json_decode($contentArtist);
}
$dataSites = $data->artist_all;

?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=11,IE=10,IE=9,IE=edge"/>
	<meta name="theme-color" content="#ffffff">
    <meta name="msapplication-TileColor" content="#ffffff">
    <link rel="icon" type="image/png" sizes="144x144" href="./assets/images/favicon.png">
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Vive tu ritmo</title>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-56Q5ZQV');</script>
    <!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-56Q5ZQV"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <header class="vtr__header">
        <div class="vtr__container">
            <a class="vtr__header__logo" href="#">
                <img src="./assets/images/logo.svg" alt="Logo" loading="lazy">
            </a>
            <nav class="vtr__header__menu">
                <!--<ul class="menu">
                    <li>
                        <a href="#">Demo link</a>
                    </li>
                    <li>
                        <a href="#">Demo link</a>
                    </li>
                    <li>
                        <a href="#">Demo link</a>
                    </li>
                </ul>-->
            </nav>
            <button class="vtr__header__hamburguer">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 60 40">
                    <g stroke="#fff" stroke-width="3">
                        <path id="top-line" d="M10,10 L50,10 Z" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"></path>
                        <path id="middle-line" d="M10,20 L50,20 Z" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"></path>
                        <path id="bottom-line" d="M10,30 L50,30 Z" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"></path>
                    </g>
                </svg>
            </button>
        </div>
    </header>

    <main>
        <section class="vtr__thanks bg-purple">
            <div class="vtr__thanks__content">
                <h1>¡Gracias por seguir esta lista!</h1>
                <p>lorem ipsum dolor sit amet consectetur adipisicing elit. Aut nihil porro animi, nesciunt laborum dolores eius ab dignissimos perferendis hic quis dolor dicta, consequuntur repellat accusantium sed! Eaque, optio assumenda?</p>
                <div class="info">
                    <div class="image">
                        <img class="image" loading="lazy" src="" alt="imagen">
                    </div>
                    <div class="text">
                        <h2 class="title"></h2>
                        <h3 class="sub-title"></h3>
                        <small class="reproductions"></small>
                    </div>
                </div>
                <a href="https://viveturitmo.com" id="redirect_button" class="vtr__button">ViveTuRitmo.com</a>
            </div>
        </section>
    </main>

    <footer class="vtr__footer">

        <div class="vtr__container">
            <hr />
            <div class="vtr__grid vtr__grid-gap-20 vtr__grid-col-6">
                <div class="vtr__item">
                    <h4>Sitios</h4>
                    <ul>
                        <?php foreach ($dataSites as $item):
                            ?>
                            <li>
                                <a href="<?php echo $item->url[0]; ?>" target="_blank"><?php echo $item->post->post_title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <!--<div class="vtr__item">
                    <h4>Ed Sheeran</h4>
                    <ul>
                        <li><a href="#">Enlace 1</a></li>
                        <li><a href="#">Enlace 2</a></li>
                        <li><a href="#">Enlace 3</a></li>
                        <li><a href="#">Enlace 4</a></li>
                    </ul>
                </div>
                <div class="vtr__item">
                    <h4>Ed Sheeran</h4>
                    <ul>
                        <li><a href="#">Enlace 1</a></li>
                        <li><a href="#">Enlace 2</a></li>
                        <li><a href="#">Enlace 3</a></li>
                        <li><a href="#">Enlace 4</a></li>
                    </ul>
                </div>
                <div class="vtr__item">
                    <h4>Ed Sheeran</h4>
                    <ul>
                        <li><a href="#">Enlace 1</a></li>
                        <li><a href="#">Enlace 2</a></li>
                        <li><a href="#">Enlace 3</a></li>
                        <li><a href="#">Enlace 4</a></li>
                    </ul>
                </div>
                <div class="vtr__item">
                    <h4>Ed Sheeran</h4>
                    <ul>
                        <li><a href="#">Enlace 1</a></li>
                        <li><a href="#">Enlace 2</a></li>
                        <li><a href="#">Enlace 3</a></li>
                        <li><a href="#">Enlace 4</a></li>
                    </ul>
                </div>
                <div class="vtr__item">
                    <h4>Ed Sheeran</h4>
                    <ul>
                        <li><a href="#">Enlace 1</a></li>
                        <li><a href="#">Enlace 2</a></li>
                        <li><a href="#">Enlace 3</a></li>
                        <li><a href="#">Enlace 4</a></li>
                    </ul>
                </div>-->
            </div>

            <div class="vtr__footer__bottom">
                <p>© 2021 Derechos reservados</p>
                <ul>
                    <li>
                        <a href="#" target="_blank">
                            <img loading="lazy" src="./assets/images/facebook.svg" alt="imagen">
                        </a>
                    </li>
                    <li>
                        <a href="#" target="_blank">
                            <img loading="lazy" src="./assets/images/twitter.svg" alt="imagen">
                        </a>
                    </li>
                    <li>
                        <a href="#" target="_blank">
                            <img loading="lazy" src="./assets/images/linkedin.svg" alt="imagen">
                        </a>
                    </li>
                    <li>
                        <a href="#" target="_blank">
                            <img loading="lazy" src="./assets/images/whatsapp.svg" alt="imagen">
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/follow.js"></script>
    <script>
     $(document).ready(function () {
        const dataTrack = sessionStorage.getItem('data_track');
        console.log(dataTrack);
        const jsonData = JSON.parse(dataTrack);
        const {type} = jsonData;
        if(type === 'main'){
            const {id, image, name, popularity, followers} = jsonData.data;
            $(".vtr__thanks__content h1").html("¡Gracias por seguir esta lista!");
            $(".info .image").attr("src", image);
            $(".info .title").html(name);
            $(".info .sub-title").html("Popularidad: " + popularity + "%");
            $(".info .reproductions").html("Seguidores: " + followers);
        } else if (type === 'ranking'){
            const {id, image, name, artist_all, artist_list_final} = jsonData.data;
            $(".vtr__thanks__content h1").html("¡Gracias por seguir esta pista!");
            $(".info .image").attr("src", image);
            $(".info .title").html(name);
            $(".info .sub-title").html(artist_list_final);
            //$(".info .reproductions").html("Seguidores: ");
        } else if (type === 'trend'){
            const {id, image, name, artist_all, popularity, artist_list_final} = jsonData.data;
            $(".vtr__thanks__content h1").html("¡Gracias por seguir esta pista!");
            $(".info .image").attr("src", image);
            $(".info .title").html(name);
            $(".info .sub-title").html(artist_list_final);
            $(".info .reproductions").html("Popularidad: " + popularity + "%");
        }



        if( dataTrack ){


            var totalTime = 5;

            let updateClock = function () {
                console.log(totalTime);
                document.getElementById('redirect_button').innerHTML = "ViveTuRitmo.com " + totalTime + " seg.";
                if(totalTime==0){
                    window.location.replace(window.urlMain);
                }else{
                    totalTime-=1;
                    setTimeout(updateClock,1000);
                }
            };

            updateClock();

            /*setTimeOut(function(){

            }, 5000);*/
        } else {
            //window.location.href =  window.location.protocol+'//'+window.location.host;
        }

    })

    </script>
</body>
</html>
